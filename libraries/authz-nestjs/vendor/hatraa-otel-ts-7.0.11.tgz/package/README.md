# o11y

## Overview

Easy Open Telemetry configuration for NestJS TypeScript applications.

## Features

- Hybrid Tracing & Metrics instrumentation
- Standardized Json Logging
- Continues Profiling 

## Installation

To install this package, use npm:

```bash
npm install @hatraa/o11y
```

## Usage

```typescript
import { otelConfig, otelLogger } from '@hatraa/o11y';

otelConfig({ serviceName: 'myservice', systemName: 'mysystem', envName: 'live' });

async getUsers(): Promise<User[]> {
    try {
      const response = await axios.get(`/users`);

      otelLogger({
        level: 'INFO',
        message: `Got back ${response.data?.length} users`,
      });

      return response.data;
    } catch (error) {
      otelLogger({
        level: 'ERROR',
        message: `There has been an error fetching the users`,
        errorid: <errorid>
      });

      return [];
    }
  }
```

## API

### Methods

`otelConfig({ serviceName: string, systemName: string, envName: Environment }): void`

Description: Initializes the Open Telemetry tracing, metricing and logging processes

Parameters:

- serviceName - name of the current service
- systemName - name of the system the current service belongs to
- envName - name of the environment the service is running within
- otelExporterOtlpEndpoint (not mandatory) - the endpoint of your telmetry exportation

**Important:** In order for the config to work properly, it MUST be the first thing you call within your main file of code, even before other imports

```typescript
import { otelConfig } from "@hatraa/o11y";

otelConfig({
  serviceName: "myservice",
  systemName: "mysystem",
  envName: "live",
  otelExporterOtlpEndpoint: "https://your-otlp-endpoint.com"
});
```

`otelLogger({ message: string, level: LogLevel }): void`

Description: Creates a log within a specific format that is exported by Open Telemetry

Parameters:

- message - text message
- level - the sevirity level of the log
- <custom_field> - any custom field

```typescript
import { otelLogger } from "@hatraa/o11y";

otelLogger({
  level: "INFO",
  message: `Fetching for users`,
  first_custom_field: "first_value",
  second_custom_field: "second_value",
});
```

`createMeter(meterName: string): Meter`

Description: Creates a new meter with a custom name

Parameters:

- meterName - name of the meter

```typescript
import { createMeter } from "@hatraa/o11y";

const usersMeter = createMeter("users-meter");
const usersMeterCounter = usersMeter.createCounter("users-counter", {
  description: "Users count",
});

usersMeterCounter.add(1, { attributeKey: "custom-attribute" });
```

`createTracer(tracerName: string): Tracer`

Description: Creates a new tracer with a custom name

Parameters:

- tracerName - name of the tracer

```typescript
import { createTracer } from "@hatraa/o11y";

const tracer = createTracer("tracer");

const getUsersFromDb = () => {
  return tracer.startActiveSpan("db.query", async (span) => {
    try {
      span.setAttribute("db.query", "SELECT * FROM users");
      span.addEvent("Querying users from db");

      const users = await USERS.findAll();

      return users;
    } catch (error) {
      span.addEvent("Error querying users from db");

      throw error;
    } finally {
      span.end();
    }
  });
};
```

### Types

`Environment`

Desctiption: List of environments' names

```typescript
type Environment = "drill" | "live" | "global";
```

`LogLevel`

Desctiption: List of possible log levels

```typescript
type LogLevel = "DEBUG" | "INFO" | "WARN" | "ERROR";
```

`OtelConfig`

Desctiption: Interface of the function 'otelConfig'

```typescript
interface OtelConfig {
  serviceName: string;
  systemName: string;
  envName: Environment;
}
```

`CustomLog`

Desctiption: Interface of the function 'otelLogger'

```typescript
interface CustomLog {
  message: string;
  level: LogLevel;
  [key: string]: any;
}
```

## Configuration

### Environment Variables

`OTEL_EXPORTER_OTLP_ENDPOINT`

Description: The route of the grpc endpoint which the data is being exported to

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://alloy-grafana-alloy:4317
```

<br>

`METRICS_PORT`

Description: The port where the metrics are available at. Default: 9464

```bash
METRICS_PORT=9464
```

<br>

`METRICS_PATH`

Description: The path where the metrics are available at. Default: /metrics

```bash
METRICS_PATH=/metrics
```

<br>

`ENABLE_PROFILING`

Description: Set to 'true' to enable CPU and memory profiling<br>
CPU profiles path: /debug/pprof/profile<br>
Memory profiles path: /debug/pprof/heap

```bash
ENABLE_PROFILING=true
```

<br>

`PROFILER_PORT`

Description: The port where the profiles are available at. Default: 6060

```bash
PROFILER_PORT=6060
```
<br>

`METRICS_PORT`

Description: The port where the metrics are available at. Default: 9464

```bash
METRICS_PORT=9464
```
<br>

`METRICS_PATH`

Description: The path where the metrics are available at. Default: /metrics

```bash
METRICS_PATH=/metrics
```
<br>

`ENABLE_PROFILING`

Description: Set to 'true' to enable CPU and memory profiling<br>
CPU profiles path: /debug/pprof/profile<br>
Memory profiles path: /debug/pprof/heap

```bash
ENABLE_PROFILING=true
```
<br>

`PROFILER_PORT`

Description: The port where the profiles are available at. Default: 6060

```bash
PROFILER_PORT=6060
```