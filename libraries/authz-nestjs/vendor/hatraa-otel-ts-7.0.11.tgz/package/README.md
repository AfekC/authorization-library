# o11y

## Overview

Easy Open Telemetry configuration for NestJS TypeScript applications.

## Features

- Hybrid Tracing & Metrics instrumentation
- Standardized Json Logging
- Continues Profiling 

## Installation

To install this package, use npm:

```bash
npm install @hatraa/otel-ts
```

## Usage

> **⚠️ #1 footgun:** `otelConfig()` MUST be the very first thing your entrypoint
> runs — before any other import — or auto-instrumentation misses modules loaded
> earlier. Put it at the top of `main.ts`.

```typescript
import { otelConfig, otelLogger } from '@hatraa/otel-ts';

otelConfig({ serviceName: 'myservice', systemName: 'mysystem', envName: 'live' });

async getUsers(): Promise<User[]> {
    try {
      const response = await axios.get(`/users`);

      otelLogger({
        level: 'INFO',
        message: `Got back ${response.data?.length} users`,
      });

      return response.data;
    } catch (error) {
      otelLogger({
        level: 'ERROR',
        message: `There has been an error fetching the users`,
        errorid: <errorid>
      });

      return [];
    }
  }
```

## API

### Methods

`otelConfig({ serviceName: string, systemName: string, envName: Environment }): void`

Description: Initializes the Open Telemetry tracing, metricing and logging processes

Parameters:

- serviceName - name of the current service
- systemName - name of the system the current service belongs to
- envName - name of the environment the service is running within
- otelExporterOtlpEndpoint (not mandatory) - the endpoint of your telmetry exportation

**Important:** In order for the config to work properly, it MUST be the first thing you call within your main file of code, even before other imports

```typescript
import { otelConfig } from "@hatraa/otel-ts";

otelConfig({
  serviceName: "myservice",
  systemName: "mysystem",
  envName: "live",
  otelExporterOtlpEndpoint: "https://your-otlp-endpoint.com"
});
```

`otelLogger({ message: string, level: LogLevel }): void`

Description: Creates a log within a specific format that is exported by Open Telemetry

Parameters:

- message - text message
- level - the sevirity level of the log
- <custom_field> - any custom field. Custom fields are nested under a `data`
  object in the output (so they can't overwrite reserved fields like
  `timestamp`/`level`/`message`/`spanContext`/`attributes`). Passing an `Error`
  value adds a top-level `stackTrace` and serializes the error (instead of `{}`).

```typescript
import { otelLogger } from "@hatraa/otel-ts";

otelLogger({
  level: "INFO",
  message: `Fetching for users`,
  first_custom_field: "first_value",
  second_custom_field: "second_value",
});
```

`createMeter(meterName: string): Meter`

Description: Creates a new meter with a custom name

Parameters:

- meterName - name of the meter

```typescript
import { createMeter } from "@hatraa/otel-ts";

const usersMeter = createMeter("users-meter");
const usersMeterCounter = usersMeter.createCounter("users-counter", {
  description: "Users count",
});

usersMeterCounter.add(1, { attributeKey: "custom-attribute" });
```

`createTracer(tracerName: string): Tracer`

Description: Creates a new tracer with a custom name

Parameters:

- tracerName - name of the tracer

```typescript
import { createTracer } from "@hatraa/otel-ts";

const tracer = createTracer("tracer");

const getUsersFromDb = () => {
  return tracer.startActiveSpan("db.query", async (span) => {
    try {
      span.setAttribute("db.query", "SELECT * FROM users");
      span.addEvent("Querying users from db");

      const users = await USERS.findAll();

      return users;
    } catch (error) {
      span.addEvent("Error querying users from db");

      throw error;
    } finally {
      span.end();
    }
  });
};
```

### Types

`Environment`

Desctiption: List of environments' names

```typescript
type Environment = "drill" | "live" | "global";
```

`LogLevel`

Desctiption: List of possible log levels

```typescript
type LogLevel = "DEBUG" | "INFO" | "WARN" | "ERROR";
```

`OtelConfig`

Desctiption: Interface of the function 'otelConfig'

```typescript
interface OtelConfig {
  serviceName: string;
  systemName: string;
  envName: Environment;
}
```

`CustomLog`

Desctiption: Interface of the function 'otelLogger'

```typescript
interface CustomLog {
  message: string;
  level: LogLevel;
  [key: string]: any;
}
```

## Configuration

### Environment Variables

`OTEL_EXPORTER_OTLP_ENDPOINT`

Description: The route of the grpc endpoint which the data is being exported to

```bash
OTEL_EXPORTER_OTLP_ENDPOINT=http://alloy-grafana-alloy:4317
```

<br>

`METRICS_PORT`

Description: The port where the metrics are available at. Default: 9464

```bash
METRICS_PORT=9464
```

<br>

`METRICS_PATH`

Description: The path where the metrics are available at. Default: /metrics

```bash
METRICS_PATH=/metrics
```

<br>

`ENABLE_PROFILING`

Description: Set to 'true' to enable CPU and memory profiling<br>
CPU profiles path: /debug/pprof/profile<br>
Memory profiles path: /debug/pprof/heap

```bash
ENABLE_PROFILING=true
```

<br>

`PROFILER_PORT`

Description: The port where the profiles are available at. Default: 6060

```bash
PROFILER_PORT=6060
```
<br>

`PROFILER_MAX_SECONDS`

Description: Upper clamp on the CPU profile `?seconds=` param, to prevent a long-running profiler DoS. Default: 60

```bash
PROFILER_MAX_SECONDS=60
```
<br>

`OTEL_TRACES_SAMPLER_ARG`

Description: Trace sampling ratio 0.0–1.0. Default 1.0 (export every span); lower it for high-traffic live services.

```bash
OTEL_TRACES_SAMPLER_ARG=0.1
```

## Operational notes

- **Endpoint security:** the metrics (`:9464/metrics`) and profiler
  (`:6060/debug/pprof/*`) servers bind all interfaces with **no auth** — the
  profiler exposes heap/CPU profiles. Only expose these ports on a
  cluster-internal network.
- **Logs are stdout-only:** unlike traces/metrics, logs are `console.log`-only
  by design. They reach a backend **only** if an external agent (Alloy/Promtail)
  scrapes stdout. There is no OTLP log export wired.
- **Alloy down:** the gRPC exporter is non-blocking and the batch processor drops
  on a full queue, so a dead `:4317` does not block startup (it logs export
  failures via OTel `diag` at ERROR).
- **Trace propagation:** pinned to W3C `tracecontext`, so traces join across
  services and with the Spring Boot lib.
- `environment` is normalized to lower-case and warns if it isn't
  `drill`/`live`/`global`. Non-numeric `*_PORT` values warn and fall back.

## End-to-end tests

`docker-compose.e2e.yml` boots the full stack — **Alloy → Tempo** (traces),
**Prometheus** (metrics), **Loki** (logs), **Grafana** — plus a minimal NestJS
sample app (`e2e/sample-app/`) that consumes this lib. A `verify` container then
drives `/hello` traffic and asserts the telemetry actually landed: a trace in
Tempo, `target_info` + the custom counter in Prometheus, and a structured JSON
log (with `spanContext` + `attributes`) in Loki.

```bash
docker compose -f docker-compose.e2e.yml up --build \
  --abort-on-container-exit --exit-code-from verify --attach verify
```

`--attach verify` streams only the `verify` container, so the output is just the
final result (drop it to also see the full stack logs while debugging).

Exit `0` = every assertion passed. Grafana (anonymous admin) is on
http://localhost:3001 for eyeballing; tear down with
`docker compose -f docker-compose.e2e.yml down -v`.

> Log collection uses Alloy's `loki.source.docker`, which reads the Docker
> socket — works on Docker Desktop and shell CI runners, not plain DinD. The CI
> `e2e` job is `manual` for that reason.